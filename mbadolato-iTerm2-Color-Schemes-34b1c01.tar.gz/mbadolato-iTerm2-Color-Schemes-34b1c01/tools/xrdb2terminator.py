#!/usr/bin/env python

# This script converts xrdb (X11) color scheme format to terminator color
# scheme format
#
# Usage:
# xrdb2terminator.py path/to/xrdb/files -d /terminator/schemes/output
#
# Author: Xabier Larrakoetxea

import os
import sys
import re
import argparse

if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description='Translate X color schemes to termiantor format')
    parser.add_argument('xrdb_path', type=str, help='path to xrdb files')
    parser.add_argument('-d', '--destiny', type=str, dest='output_path',
                        help='path where terminator config files will be' +
                        ' created, if not provided then will be printed')

    args = parser.parse_args()


    # The regexes to match the colors
    color_regex = re.compile("#define +Ansi_(\d+)_Color +(#[A-Fa-f0-9]{6})")
    bg_regex = re.compile("#define +Background_Color +(#[A-Fa-f0-9]{6})")
    fg_regex = re.compile("#define +Foreground_Color +(#[A-Fa-f0-9]{6})")
    cursor_regex = re.compile("#define +Cursor_Color +(#[A-Fa-f0-9]{6})")

    # File regex
    xrdb_regex = re.compile("(.+)\.[xX][rR][dD][bB]")

    for i in filter(lambda x: xrdb_regex.match(x), os.listdir(args.xrdb_path)):

        # per file
        with open(os.path.join(args.xrdb_path, i)) as f:
            lines = f.readlines()

        # Search special colors
        color_file = "\n".join(lines)

        bg_color = bg_regex.search(color_file).group(1)
        fg_color = fg_regex.search(color_file).group(1)
        cursor_color = cursor_regex.search(color_file).group(1)

        # Search palette
        colors = sorted(filter(lambda x: color_regex.match(x), lines),
                        key=lambda x: int(color_regex.match(x).group(1)))

        # Create the color string
        colors = ":".join(map(lambda x: color_regex.match(x).group(2), colors))

        scheme = """
[[{name}]]
    palette = "{pl}"
    background_color = "{bg}"
    cursor_color = "{cr}"
    foreground_color = "{fg}"
    background_image = None
"""

        output = scheme.format(name=xrdb_regex.match(i).group(1),
                               pl=colors,
                               bg=bg_color,
                               cr=cursor_color,
                               fg=fg_color)

        if not args.output_path:
            print(output)
        else:
            dest = os.path.join(args.output_path, xrdb_regex.match(i).group(1))
            with open('{0}.config'.format(dest), 'w+') as f:
                f.write(output)
